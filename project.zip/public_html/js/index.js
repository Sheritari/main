document.addEventListener('DOMContentLoaded', () => {
    const grid = document.querySelector('.grid');
    const ggg = document.getElementById("score");
    const hum = document.createElement('div');
    let isGameOver = false;
    let speed = 7;
    let platformCount = 14;
    let cloudCount = 6;
    let clouds = [];
    let moneys = [];
    let type;
    let checkPlatforms = [];
    let types = [1];
    let candys = [];
    let platforms = [];
    let persona = 1;
    let moneyCount;
    let score;
    let humLeftSpace = 50;
    let raitValue = document.getElementById("rait");
    let hPers;
    let gravity = 0.2;
    let keyState = {};
    let py;
    let q = 60;
    let qq = 1;
    let vy = 11;
    let flag = true;
    let flagflag = true;
    let str = document.getElementById("start");
    str.addEventListener("click", start);
    let menu = document.getElementById("menu");
    let game = document.getElementById("game");
    let restarts = document.getElementById("restart");
    restarts.addEventListener("click", restart);
    let main = document.getElementById("main");
    main.addEventListener("click",showMenu);
    let shops = document.getElementById("shop");
    shops.addEventListener("click", showShopMenu);
    let monValue = document.getElementById("moneys");
    let name = document.getElementById("name");
//    SKINS
    let shp=document.getElementById("shop1");
    let backs=document.getElementById("back");
    backs.addEventListener("click", backMenu);
    let pers=document.getElementById("pers");
    let ext=document.getElementById("ext");
    let per1 = document.getElementById("per1");
    let per2 = document.getElementById("per2");
    let per3 = document.getElementById("per3");
    let per4 = document.getElementById("per4");
    let per5 = document.getElementById("per5");
    let per6 = document.getElementById("per6");
    let gal1 = document.getElementById("gal1");
    gal1.addEventListener("click", choicePers);
    let gal2 = document.getElementById("gal2");
    gal2.addEventListener("click", choicePers);
    let gal3 = document.getElementById("gal3");
    gal3.addEventListener("click", choicePers);
    let gal4 = document.getElementById("gal4");
    gal4.addEventListener("click", choicePers);
    let gal5 = document.getElementById("gal5");
    gal5.addEventListener("click", choicePers);
    let gal6 = document.getElementById("gal6");
    gal6.addEventListener("click", choicePers);
    let acs0 = document.getElementById("acs0");
    let gul0 = document.getElementById("gul0");
    gul0.addEventListener("click", choiceAcs);
    let acs1 = document.getElementById("acs1");
    let gul1 = document.getElementById("gul1");
    gul1.addEventListener("click", choiceAcs);
    let pickPer = 1;
    let pickAcs = 0;
//    SKINS
//    РАБОТА С ЭКРАНОМ
    let conH = screen.height;
    let qqq = document.getElementById("skoons");
    let hq = window.getComputedStyle(qqq).height;
    let qqq2 = document.getElementById("skoons2");
    let hq2 = window.getComputedStyle(qqq2).height;
    let humBottomSpace = 290 + parseInt(hq);
//    РАБОТА С ЭКРАНОМ
    let perk = document.getElementById("perk");
    let ext1 = document.getElementById("ext1");
    let checkMen = 1;
        document.getElementById("ext1").addEventListener("click",function(){
        pers.style.display="none";
        ext.style.display="block";
        perk.style.backgroundColor="rgb(162, 130, 233)";
        ext1.style.backgroundColor="blue";
        checkMen = 2;
    });
        perk.addEventListener("click",function(){
        pers.style.display="block";
        ext.style.display="none";
        perk.style.backgroundColor="blue";
        ext1.style.backgroundColor="rgb(162, 130, 233)";
        checkMen = 1;
    });

    class Cloud {
        constructor(newCloudBottom) {
            this.left = Math.random() * 350;
            this.bottom = newCloudBottom + 230;
            this.top = 670 + parseInt(hq) + parseInt(hq2) - this.bottom;
            this.visual2 = document.createElement('div');
            const visual2 = this.visual2;
            let rnd = Math.floor(Math.random() * 5 + 1);
            let rnd2 = Math.random();
            if (rnd2 < 0.5)
                rnd2 += 0.5;
            if (rnd2 > 0.75)
                rnd2 -= 0.25;
            let s = "url(images/clouds/" + rnd + ".png)";
            visual2.setAttribute("style", "background-image:" + s + ";opacity: " + rnd2 + ";z-index: -5;");
            visual2.classList.add('cloud');
            visual2.style.marginLeft = this.left + 'px';
            visual2.style.top = this.top + 'px';
            grid.appendChild(visual2);
        }
    }

    function createClouds() {
        for (let i = 0; i < cloudCount; i++) {
            let cloudGap = 670 / cloudCount;
            let newCloudBottom = parseInt(hq) + i * cloudGap;
            let newCloud = new Cloud(newCloudBottom);
            clouds.push(newCloud);
        }
    }

    class Candy {
        constructor(newCandyBottom, newCandyLeft, type, moves) {
            let rnd = Math.random() * 43;
            this.left = newCandyLeft + rnd;
            this.bottom = newCandyBottom;
            this.top = 670 + parseInt(hq) + parseInt(hq2) - this.bottom;
            this.type = type;
            this.moves = moves;
            this.leftP = newCandyLeft;
            this.visual4 = document.createElement("div");
            this.visual4.style.zIndex = -4;
            const visual4 = this.visual4;
            if (this.type == 1)
                visual4.classList.add("candyPink");
            else if (this.type == 2)
                visual4.classList.add("candyBlue");
            visual4.style.marginLeft = this.left + "px";
            visual4.style.top = this.top + "px";
            grid.appendChild(visual4);
        }
    }
    class Money {
        constructor(newMoneyBottom, newMoneyLeft, moves) {
            let rnd = Math.random() * 43;
            this.left = newMoneyLeft + rnd;
            this.bottom = newMoneyBottom;
            this.top = 670 + parseInt(hq) + parseInt(hq2) - this.bottom;
            this.moves = moves;
            this.leftP = newMoneyLeft;
            this.visual3 = document.createElement("div");
            this.visual3.style.zIndex = -4;
            const visual3 = this.visual3;
            visual3.classList.add("money");
            visual3.style.marginLeft = this.left + "px";
            visual3.style.top = this.top + "px";
            grid.appendChild(visual3);
        }
    }
    class Platform {
        constructor(newPlatBottom, type) {
            this.left = Math.random() * 443;
            this.bottom = newPlatBottom + 230;
            this.top = 670 + parseInt(hq) + parseInt(hq2) - this.bottom;
            this.type = type;
            this.moves;
            this.visual = document.createElement('div');
            this.visual.style.zIndex = -4;
            const visual = this.visual;
            if (type == 1)
                visual.classList.add('platformStandart');
            if (type == 2)
                visual.classList.add("platformDamaged");
            if (type == 3) {
                this.moves = true;
                visual.classList.add("platformMoved");
            }
            visual.style.marginLeft = this.left + 'px';
            visual.style.top = this.top + 'px';
            grid.appendChild(visual);
        }
    }


    function createPlatforms() {
        for (let i = 0; i < platformCount; i++) {
            let platGap = 670 / platformCount;
            let newPlatBottom = parseInt(hq) + i * platGap;
            let newPlatform = new Platform(newPlatBottom, 1);
            platforms.push(newPlatform);
            let rnd = Math.random() * 10000;
            let rnd2 = Math.random() * 10000;
            if (rnd > 8700 && rnd2 < 9800) {
                let newMoneyBottom = newPlatform.bottom + 44;
                let newMoney = new Money(newMoneyBottom, newPlatform.left, 3);
                moneys.push(newMoney);
            } else if (rnd2 > 9800 && rnd2 < 9950) {
                let newCandyBottom = newPlatform.bottom + 44;
                let newCandy = new Candy(newCandyBottom, newPlatform.left, 1, 3);
                candys.push(newCandy);
            } else if (rnd2 > 9950) {
                let newCandyBottom = newPlatform.bottom + 44;
                let newCandy = new Candy(newCandyBottom, newPlatform.left, 2, 3);
                candys.push(newCandy);
            }
        }
    }

    function createHum() {
        grid.appendChild(hum);
        hum.classList.add('hum');
        humLeftSpace = platforms[0].left;
        hum.style.marginLeft = humLeftSpace - 10 + 'px';
        hum.style.bottom = humBottomSpace - 10 + 'px';
        if (pickAcs == 0) {
            hPers = 70;
            hum.style.height = 70 + "px";
        }
        else if (pickAcs == 1) {
            hPers = 74;
            hum.style.height = 74 + "px";
        }
        py = 315 + parseInt(hq);
    }

    function jump() {
        vy = -8;
    }

    function highJump() {
        vy = -18;
    }

    function ultraHighJump() {
        vy = -28;
    }

    function collides() {
        platforms.forEach(platform => {
            if (
                    ((py + hPers) >= platform.top) &&
                    ((py + hPers) <= (platform.top + 15)) &&
                    ((humLeftSpace + 43) >= platform.left) &&
                    (humLeftSpace + 20 <= (platform.left + 90))
                    ) {
                if (platform.type !== 2) {
                    if (pickAcs == 0){
                    let s = "url(images/characters/"+(persona+1)+".png)";
                    hum.setAttribute("style", "background-image:" + s);
                }
                else if (pickAcs == 1){
                    let s = "url(images/characters/"+(parseInt(persona)+1)+"acs.png)";
                    hum.setAttribute("style", "background-image:" + s);
                }
                    jump();
                } else if (platform.type !== 3) {
                    let visual = platform.visual;
                    visual.classList.remove("platformDamaged");
                    visual.classList.add("platformCrush");
                    setTimeout(function () {
                        visual.style.display = "none";
                    }, 1000);
                }
            }
        });
    }
    
    function intersec(obj, idx){
            return ((py >= obj[idx].top && py <= obj[idx].top + 44 && humLeftSpace + 14 >= obj[idx].left && humLeftSpace + 14 <= obj[idx].left + 44) ||
                    (py + hPers >= obj[idx].top && py + hPers <= obj[idx].top + 44 && humLeftSpace + 49 >= obj[idx].left && humLeftSpace + 49 <= obj[idx].left + 44) ||
                    (humLeftSpace + 14 >= obj[idx].left && humLeftSpace + 14 <= obj[idx].left + 44 && py + hPers >= obj[idx].top && py + hPers <= obj[idx].top + 44) ||
                    (humLeftSpace + 49 >= obj[idx].left && humLeftSpace + 49 <= obj[idx].left + 44 && py >= obj[idx].top && py <= obj[idx].top + 44) ||
                    (obj[idx].top >= py && obj[idx].top <= py + hPers && obj[idx].top + 44 >= py + hPers && obj[idx].left >= humLeftSpace + 14 && obj[idx].left <= humLeftSpace + 49 && obj[idx].left + 44 <= humLeftSpace + 49) ||
                    (obj[idx].top >= py && obj[idx].top <= py + hPers && obj[idx].top + 44 <= py + hPers && obj[idx].left + 44 >= humLeftSpace + 14 && obj[idx].left + 44 <= humLeftSpace + 49 && obj[idx].left <= humLeftSpace) ||
                    (obj[idx].top >= py && obj[idx].top <= py + hPers && obj[idx].top + 44 <= py + hPers && obj[idx].left >= humLeftSpace + 14 && obj[idx].left <= humLeftSpace + 49 && obj[idx].left + 44 >= humLeftSpace + 49) ||
                    (obj[idx].top <= py && obj[idx].top + 44 >= py && obj[idx].top + 44 <= py + hPers && obj[idx].left >= humLeftSpace + 14 && obj[idx].left <= humLeftSpace + 49 && obj[idx].left + 44 <= humLeftSpace + 49)
                    )
    }
    
    function overlap() {
        for (let i = 0; i < moneys.length; i++) {
            if (intersec(moneys, i))
            {
                let t = moneys[i];
                moneys[i] = moneys[0];
                moneys[0] = t;
                let firstMoney = moneys[0].visual3;
                firstMoney.classList.remove('money');
                firstMoney.remove();
                moneys.shift();
                moneyCount = parseInt(moneyCount) + 150;
                localStorage.setItem("mon", moneyCount);
                monValue.innerHTML = localStorage.getItem("mon");
            }
        }
        for (let i = 0; i < candys.length; i++) {
            if (intersec(candys, i))
            {
                let t = candys[i];
                candys[i] = candys[0];
                candys[0] = t;
                let firstCandy = candys[0].visual4;
                if (candys[0].type == 1) {
                    if (pickAcs == 0){
                    let s = "url(images/characters/"+(persona+1)+".png)";
                    hum.setAttribute("style", "background-image:" + s);
                }
                else if (pickAcs == 1){
                    let s = "url(images/characters/"+(parseInt(persona)+1)+"acs.png)";
                    hum.setAttribute("style", "background-image:" + s);
                }
                    hum.style.top = py + "px";
                    firstCandy.classList.remove('candyPink');
                    highJump();
                } else if (candys[0].type == 2) {
                    if (pickAcs == 0){
                    let s = "url(images/characters/"+(persona+1)+".png)";
                    hum.setAttribute("style", "background-image:" + s);
                }
                else if (pickAcs == 1){
                    let s = "url(images/characters/"+(parseInt(persona)+1)+"acs.png)";
                    hum.setAttribute("style", "background-image:" + s);
                }
                    hum.style.top = py + "px";
                    firstCandy.classList.remove("candyBlue");
                    ultraHighJump();
                }
                firstCandy.remove();
                candys.shift();
            }
        }
    }

    function moveAll() {
        if (py >= 670 + parseInt(hq2)) {
            gameOver();
        }
        if (py >= 335 + parseInt(hq2) - 70) {
            if (vy > 0) {
                let s = "url(images/characters/"+persona+".png)";
                hum.setAttribute("style", "background-image:" + s);
                collides();
            }
            py += vy;
            vy += gravity;
            hum.style.top = py + 'px';
        } else {
            if (vy < 0) {
                vy += gravity;
                clouds.forEach(cloud => {
                    cloud.top -= vy;
                    let visual = cloud.visual2;
                    visual.style.top = cloud.top + "px";
                    if (cloud.top >= 670 + parseInt(hq2)) {
                        let firstCloud = clouds[0].visual2;
                        firstCloud.classList.remove('cloud');
                        firstCloud.remove();
                        clouds.shift();
                        var newCloud = new Cloud(670 + parseInt(hq));
                        clouds.push(newCloud);
                    }
                });
                platforms.forEach(platform => {
                    platform.top -= vy;
                    score+=15;
                    let visual = platform.visual;
                    visual.style.top = platform.top + 'px';
                    if (platform.top >= 670 + parseInt(hq2)) {
                        let firstPlatform = platforms[0].visual;
                        if (platforms[0].type == 1)
                            firstPlatform.classList.remove('platformStandart');
                        else if (platforms[0].type == 2)
                            firstPlatform.classList.remove('platformDamaged');
                        else if (platforms[0].type == 3)
                            firstPlatform.classList.remove('platformMoved');
                        firstPlatform.remove();
                        platforms.shift();
                        type = types[Math.floor(Math.random() * types.length)];
                        checkPlatforms.push(type);
                        for (let i = 0; i < checkPlatforms.length - 1; i++) {
                            if (checkPlatforms[i] == 2 && checkPlatforms[i + 1] == 2 && checkPlatforms.length > 1) {
                                type = 1;
                                checkPlatforms = [];
                            }
                        }
                        var newPlatform = new Platform(670 + parseInt(hq), type);
                        platforms.push(newPlatform);
                        let rnd = Math.random() * 10000;
                        let rnd2 = Math.random() * 10000;
                        if (rnd > 8700 && rnd2 < 9800) {
                            let newMoneyBottom = newPlatform.bottom + 44;
                            let newMoney;
                            if (type == 3)
                            newMoney = new Money(newMoneyBottom, newPlatform.left, 1);
                            else newMoney = new Money(newMoneyBottom, newPlatform.left, 3);
                            moneys.push(newMoney);
                        }
                        if (rnd2 > 9800 && rnd2 < 9950) {
                            let newCandyBottom = newPlatform.bottom + 44;
                            let newCandy;
                            if (type == 3)
                            newCandy = new Candy(newCandyBottom, newPlatform.left, 1, 1);
                            else{ 
                                newCandy = new Candy(newCandyBottom, newPlatform.left, 1, 3);
                            }
                            candys.push(newCandy);
                        } else if (rnd2 > 9950) {
                            let newCandyBottom = newPlatform.bottom + 44;
                            let newCandy;
                            if (type == 3)
                            newCandy = new Candy(newCandyBottom, newPlatform.left, 2, 1);
                            else newCandy = new Candy(newCandyBottom, newPlatform.left, 2, 3);
                            candys.push(newCandy);
                        }
                    }
                });
                for (let i = 0; i < moneys.length; i++) {
                    moneys[i].top -= vy;
                    let visual = moneys[i].visual3;
                    visual.style.top = moneys[i].top + "px";
                    if (moneys[i].top + 35 >= 670 + parseInt(hq2) + 35) {
                        let t = moneys[i];
                        moneys[i] = moneys[0];
                        moneys[0] = t;
                        let firstMoney = moneys[0].visual3;
                        firstMoney.classList.remove('money');
                        firstMoney.remove();
                        moneys.shift();
                    }
                }
                for (let i = 0; i < candys.length; i++) {
                    candys[i].top -= vy;
                    let visual = candys[i].visual4;
                    visual.style.top = candys[i].top + "px";
                    if (candys[i].top + 35 >= 670 + parseInt(hq2) + 35) {
                        let t = candys[i];
                        candys[i] = candys[0];
                        candys[0] = t;
                        let firstCandy = candys[0].visual4;
                        if (candys[0].type == 1)
                            firstCandy.classList.remove('candyPink');
                        else if (candys[0].type == 2)
                            firstCandy.classList.remove("candyBlue");
                        firstCandy.remove();
                        candys.shift();
                    }
                }
            } else if (vy >= 0) {
                py += vy;
                vy += gravity;
                hum.style.top = py + 'px';

            }
        }
    }

    function gameLoop() {
        if (!isGameOver) {
            hq = window.getComputedStyle(qqq).height;
            hq2 = window.getComputedStyle(qqq2).height;
            platforms.forEach(platform=>{
                let visual2 = platform.visual;
            if (platform.type === 3){
           if (platform.left > 0 && platform.moves){
               platform.left -= (q/15/2);
               visual2.style.marginLeft = platform.left + 'px';
           }
           else if (platform.left <= 0 && platform.moves){
               platform.moves = false;
           }
           else if (platform.left + 90 < 533 && !platform.moves){
               platform.left += (q/15/2);
                      visual2.style.marginLeft = platform.left + 'px';
           }
           else{
               platform.moves = true;
           }

       }
        });
            candys.forEach(candy=>{
                let visual2 = candy.visual4;
           if (candy.leftP > 0 && candy.moves == 1){
               candy.left -= (q/15/2);
               candy.leftP -= (q/15/2);
               visual2.style.marginLeft = candy.left + 'px';
           }
           else if (candy.leftP <= 0 && candy.moves == 1){
               candy.moves = 2;
           }
           else if (candy.leftP + 90 < 533 && candy.moves == 2){
               candy.leftP += (q/15/2);
               candy.left += (q/15/2);
                      visual2.style.marginLeft = candy.left + 'px';
           }
           else if (candy.moves !== 3){
               candy.moves = 1;
           }
            });
            moneys.forEach(money=>{
                let visual2 = money.visual3;
           if (money.leftP > 0 && money.moves == 1){
               money.left -= (q/15/2);
               money.leftP -= (q/15/2);
               visual2.style.marginLeft = money.left + 'px';
           }
           else if (money.leftP <= 0 && money.moves == 1){
               money.moves = 2;
           }
           else if (money.leftP + 90 < 533 && money.moves == 2){
               money.leftP += (q/15/2);
               money.left += (q/15/2);
                      visual2.style.marginLeft = money.left + 'px';
           }
           else if (money.moves !== 3){
               money.moves = 1;
           }
            });
            if (Math.floor(score / 15000) > 0 && Math.floor(score / 15000) == qq) {
                q += 10;
                qq++;
            }
            ggg.innerHTML = score;
            for (let i = 0; i < platformCount - 1; i++) {
                if (platforms[i].top - platforms[i + 1].top > 140) {
                    platforms[i + 1].top += 70;
                    let visual = platforms[i + 1].visual;
                    visual.style.top = platforms[i + 1].top + "px";
                }
            }
            for (let i = 0; i < platformCount - 2; i++) {
                if (platforms[i].top - platforms[i + 2].top > 140 && platforms[i + 1].type == 2) {
                    platforms[i + 1].type = 1;
                    platforms[i + 1].visual.classList.remove("platformDamaged");
                    platforms[i + 1].visual.classList.add("platformStandart");
                }
            }
            if (score >= 100000) types = [3, 3, 3, 3, 2, 2, 2, 2, 2, 2];
            else if (score >= 50000 && score < 100000)
                types = [2, 2, 2, 2, 2, 3, 3, 3, 3, 3];
            else if (score >= 20000 && score < 50000)
                types = [1, 1, 2, 2, 2, 2, 3, 3, 3, 3];
            else if (score >= 10000 && score < 20000)
                types = [1, 1, 1, 1, 1, 1, 2, 2, 3, 3];
            else if (score >= 5000 && score < 10000)
                types = [1, 1, 1, 1, 1, 1, 1, 1, 2, 3];
            overlap();
            moveAll();
            if (keyState[37] || keyState[65]) {
                if (humLeftSpace - speed <= -77) {
                    humLeftSpace = 533 + 75;
                }
                humLeftSpace -= speed;
            }

            if (keyState[39] || keyState[68]) {
                if (humLeftSpace + speed >= 610) {
                    humLeftSpace = -77;
                }
                humLeftSpace += speed;
            }
            hum.style.marginLeft = humLeftSpace + 'px';
            setTimeout(gameLoop, 1000 / q);
        }
    }

    function gameOver() {
        isGameOver = true;
        cleanUp();
    }

    function cleanUp() {
        if (platforms.length > 0) {
            platforms.forEach(platform => {
                platform.top -= 20;
                let visual = platform.visual;
                visual.style.top = platform.top + 'px';
                if (platform.top <= -670 - parseInt(hq)) {
                    let firstPlatform = platforms[0].visual;
                    if (platforms[0].type == 1)
                    firstPlatform.classList.remove('platformStandart');
                    else if (platforms[0].type == 2)
                        firstPlatform.classList.remove('platformDamaged');
                    else if (platforms[0].type == 3)
                        firstPlatform.classList.remove('platformMoved');
                    firstPlatform.remove();
                    platforms.shift();
                }
            });
        }
        if (moneys.length > 0) {
            moneys.forEach(money => {
                money.top -= 20;
                let visual = money.visual3;
                visual.style.top = money.top + 'px';
                if (money.top <= -670 - parseInt(hq)) {
                    let firstMoney = moneys[0].visual3;
                    firstMoney.classList.remove('money');
                    firstMoney.remove();
                    moneys.shift();
                }
            });
        }
        if (candys.length > 0) {
            candys.forEach(candy => {
                candy.top -= 20;
                let visual = candy.visual4;
                visual.style.top = candy.top + 'px';
                if (candy.top <= -670 - parseInt(hq)) {
                    let firstCandy = candys[0].visual4;
                    if (candys[0].type == 1)
                        firstCandy.classList.remove('candyPink');
                    else if (candys[0].type == 2)
                        firstCandy.classList.remove("candyBlue");
                    firstCandy.remove();
                    candys.shift();
                }
            });
        }
        if (clouds.length > 0) {
            clouds.forEach(cloud => {
                cloud.top -= 20;
                let visual = cloud.visual2;
                visual.style.top = cloud.top + 'px';
                if (cloud.top <= -670 - parseInt(hq)) {
                    let firstCloud = clouds[0].visual2;
                    firstCloud.classList.remove('cloud');
                    firstCloud.remove();
                    clouds.shift();
                }
            });
        }
        if (py > 335 + parseInt(hq2) - hPers + 100 && flag) {
            py -= 12;
            hum.style.top = py + 'px';
        } else {
            flag = false;
            if (py < 730 + parseInt(hq2)) {
                vy = 8;
                py += vy;
                vy += gravity;
                hum.style.top = py + 'px';
            } else {
                flagflag = false;
                py = 350 + parseInt(hq);
                hum.style.top = py + "px";
                hum.style.marginLeft = -200 + 'px';
            }
        }
        if (flagflag)
            setTimeout(cleanUp, 1000 / 60);
        else {
            if (parseInt(localStorage.getItem("rait")) < score){
            localStorage.setItem("rait", score);
            if (parseInt(localStorage.getItem("rait")) >= 1000000) raitValue.style.color = "red";
            raitValue.innerHTML = "Рекорд" +"<br>" + score;
        };
            restarts.style.display = "block";
            main.style.display = "block";
        }
    }

    function restart() {
        isGameOver = false;
        flag = true;
        flagflag = true;
        restarts.style.display = "none";
        main.style.display = "none";
        clouds = [];
        platforms = [];
        q = 60;
        qq = 1;
        moneys = [];
        candys = [];
        score = 0;
        start();
    }

    function start() {
        if (localStorage.getItem("mon") != null)
        moneyCount = localStorage.getItem("mon");
        else moneyCount = 0;
        monValue.innerHTML = moneyCount;
        menu.style.display = "none";
        game.style.display = "flex";
        shops.style.display = "none";
        str.style.display = "none";
        document.body.style.backgroundColor = "cyan";
        
        if (!isGameOver) {
            createPlatforms();
            createClouds();
            createHum();
            gameLoop();
        }
    }
    
    function showShopMenu(){
        shops.style.display = "none";
        str.style.display = "none";
        name.style.display = "none";
        menu.style.display="none";
        shp.style.display="block";
        if (checkMen == 1)
        ext.style.display="none";
        else if (checkMen == 2)
            ext.style.display="block";
    }

    function backMenu(){
        shops.style.display="block";
        str.style.display = "block";
        name.style.display = "block";
        menu.style.display="block";
        shp.style.display="none";
    }
    
    function checkPers(){
        if (localStorage.getItem("pers3") == "true") {
            gal3.innerHTML = "Выбрать";
        }
        if (localStorage.getItem("pers4") == "true") {
            gal4.innerHTML = "Выбрать";
        }
        if (localStorage.getItem("pers5") == "true"){
            gal5.innerHTML = "Выбрать";
        }
        if (localStorage.getItem("pers6") == "true"){
            gal6.innerHTML = "Выбрать";
        }
        
        
        if (pickPer == 1) {
            per1.setAttribute("style", "background-image:" + "url(images/characters/1selected.png)");
            per2.setAttribute("style", "background-image:" + "url(images/characters/3.png)");
            per3.setAttribute("style", "background-image:" + "url(images/characters/5.png)");
            per4.setAttribute("style", "background-image:" + "url(images/characters/7.png)");
            per5.setAttribute("style", "background-image:" + "url(images/characters/9.png)");
            per6.setAttribute("style", "background-image:" + "url(images/characters/11.png)");
            gal1.innerHTML = "Выбран";
    }
    else if (pickPer == 3) {
            per1.setAttribute("style", "background-image:" + "url(images/characters/1.png)");
            per2.setAttribute("style", "background-image:" + "url(images/characters/3selected.png)");
            per3.setAttribute("style", "background-image:" + "url(images/characters/5.png)");
            per4.setAttribute("style", "background-image:" + "url(images/characters/7.png)");
            per5.setAttribute("style", "background-image:" + "url(images/characters/9.png)");
            per6.setAttribute("style", "background-image:" + "url(images/characters/11.png)");
            gal2.innerHTML = "Выбран";
    }
    else if (pickPer == 5) {
            per1.setAttribute("style", "background-image:" + "url(images/characters/1.png)");
            per2.setAttribute("style", "background-image:" + "url(images/characters/3.png)");
            per3.setAttribute("style", "background-image:" + "url(images/characters/5selected.png)");
            per4.setAttribute("style", "background-image:" + "url(images/characters/7.png)");
            per5.setAttribute("style", "background-image:" + "url(images/characters/9.png)");
            per6.setAttribute("style", "background-image:" + "url(images/characters/11.png)");
            gal3.innerHTML = "Выбран";
    }
    else if (pickPer == 7) {
            per1.setAttribute("style", "background-image:" + "url(images/characters/1.png)");
            per2.setAttribute("style", "background-image:" + "url(images/characters/3.png)");
            per3.setAttribute("style", "background-image:" + "url(images/characters/5.png)");
            per4.setAttribute("style", "background-image:" + "url(images/characters/7selected.png)");
            per5.setAttribute("style", "background-image:" + "url(images/characters/9.png)");
            per6.setAttribute("style", "background-image:" + "url(images/characters/11.png)");
            gal4.innerHTML = "Выбран";
    }
    else if (pickPer == 9) {
            per1.setAttribute("style", "background-image:" + "url(images/characters/1.png)");
            per2.setAttribute("style", "background-image:" + "url(images/characters/3.png)");
            per3.setAttribute("style", "background-image:" + "url(images/characters/5.png)");
            per4.setAttribute("style", "background-image:" + "url(images/characters/7.png)");
            per5.setAttribute("style", "background-image:" + "url(images/characters/9selected.png)");
            per6.setAttribute("style", "background-image:" + "url(images/characters/11.png)");
            gal5.innerHTML = "Выбран";
    }
    else if (pickPer == 11) {
            per1.setAttribute("style", "background-image:" + "url(images/characters/1.png)");
            per2.setAttribute("style", "background-image:" + "url(images/characters/3.png)");
            per3.setAttribute("style", "background-image:" + "url(images/characters/5.png)");
            per4.setAttribute("style", "background-image:" + "url(images/characters/7.png)");
            per5.setAttribute("style", "background-image:" + "url(images/characters/9.png)");
            per6.setAttribute("style", "background-image:" + "url(images/characters/11selected.png)");
            gal6.innerHTML = "Выбран";
    }
}   

    function checkAcs(){
        if (localStorage.getItem("acs1") == "true") {
            gul1.innerHTML = "Выбрать";
        }
        
        
        if (pickAcs == 0) {
            acs0.setAttribute("style", "background-image:" + "url(images/characters/acs0selected.png)");
            acs1.setAttribute("style", "background-image:" + "url(images/characters/acs1.png)");
            persona = parseInt(localStorage.getItem("pers"));
            localStorage.setItem("pers", persona);
            localStorage.setItem("acs", 0);
            gul0.innerHTML = "Выбран";
    }
    else if (pickAcs == 1) {
            acs0.setAttribute("style", "background-image:" + "url(images/characters/acs0.png)");
            acs1.setAttribute("style", "background-image:" + "url(images/characters/acs1selected.png)");
            persona = persona + "acs";
            localStorage.setItem("pers", persona);
            localStorage.setItem("acs", 1);
            gul1.innerHTML = "Выбран";
    }
}

    function choiceAcs(){
        if (this.innerHTML == "Выбрать" || parseInt(this.innerHTML) >= 0) {
            if (this.value == "0") { 
                acs0.setAttribute("style", "background-image:" + "url(images/characters/acs0selected.png)");
                acs1.setAttribute("style", "background-image:" + "url(images/characters/acs1.png)");
                this.innerHTML = "Выбран";
                if (localStorage.getItem("acs1") == "true")
                gul1.innerHTML = "Выбрать";
                pickAcs = 0;
                persona = parseInt(persona);
                localStorage.setItem("pers", persona);
                localStorage.setItem("acs", pickAcs);
            }
            else if (this.value == "1") {
                if (localStorage.getItem("acs1") == "true"){
                acs0.setAttribute("style", "background-image:" + "url(images/characters/acs0.png)");
                acs1.setAttribute("style", "background-image:" + "url(images/characters/acs1selected.png)");
                this.innerHTML = "Выбран";
                gul0.innerHTML = "Выбрать";
                persona = persona + "acs";
                pickAcs = 1;
                localStorage.setItem("pers", persona);
                localStorage.setItem("acs", pickAcs);
            }
                else if (parseInt(localStorage.getItem("mon")) >= parseInt(this.innerHTML)) {
                        let temp = parseInt(localStorage.getItem("mon")) - parseInt(this.innerHTML);
                        localStorage.setItem("mon", temp);
                        localStorage.setItem("acs1", "true");
                        document.getElementById("moneys4").innerHTML = localStorage.getItem("mon");
                        acs0.setAttribute("style", "background-image:" + "url(images/characters/acs0.png)");
                        acs1.setAttribute("style", "background-image:" + "url(images/characters/acs1selected.png)");
                        this.innerHTML = "Выбран";
                        gul0.innerHTML = "Выбрать";
                        persona = persona + "acs";
                        pickAcs = 1;
                        localStorage.setItem("pers", persona);
                        localStorage.setItem("acs", pickAcs);
                    }
                }
    }
    }


//    SKINS



    function choicePers(){
        if (this.innerHTML == "Выбрать" || parseInt(this.innerHTML) >= 0) {
            if (this.value == "1") { 
                per1.setAttribute("style", "background-image:" + "url(images/characters/1selected.png)");
                per2.setAttribute("style", "background-image:" + "url(images/characters/3.png)");
                per3.setAttribute("style", "background-image:" + "url(images/characters/5.png)");
                per4.setAttribute("style", "background-image:" + "url(images/characters/7.png)");
                per5.setAttribute("style", "background-image:" + "url(images/characters/9.png)");
                per6.setAttribute("style", "background-image:" + "url(images/characters/11.png)");
                this.innerHTML = "Выбран";
                gal2.innerHTML = "Выбрать";
                if (localStorage.getItem("pers3") == "true")
                gal3.innerHTML = "Выбрать";
                if (localStorage.getItem("pers4") == "true")
                gal4.innerHTML = "Выбрать";
                if (localStorage.getItem("pers5") == "true")
                gal5.innerHTML = "Выбрать";
                if (localStorage.getItem("pers6") == "true")
                gal6.innerHTML = "Выбрать";
                persona = 1;
                localStorage.setItem("pers", persona);
            }
            else if (this.value == "2") { 
                per1.setAttribute("style", "background-image:" + "url(images/characters/1.png)");
                per2.setAttribute("style", "background-image:" + "url(images/characters/3selected.png)");
                per3.setAttribute("style", "background-image:" + "url(images/characters/5.png)");
                per4.setAttribute("style", "background-image:" + "url(images/characters/7.png)");
                per5.setAttribute("style", "background-image:" + "url(images/characters/9.png)");
                per6.setAttribute("style", "background-image:" + "url(images/characters/11.png)");
                this.innerHTML = "Выбран";
                gal1.innerHTML = "Выбрать";
                if (localStorage.getItem("pers3") == "true")
                gal3.innerHTML = "Выбрать";
                if (localStorage.getItem("pers4") == "true")
                gal4.innerHTML = "Выбрать";
                if (localStorage.getItem("pers5") == "true")
                gal5.innerHTML = "Выбрать";
                if (localStorage.getItem("pers6") == "true")
                gal6.innerHTML = "Выбрать";
                persona = 3;
                localStorage.setItem("pers", persona);
            }
            else if (this.value == "3") {
                if (localStorage.getItem("pers3") == "true"){
                per1.setAttribute("style", "background-image:" + "url(images/characters/1.png)");
                per2.setAttribute("style", "background-image:" + "url(images/characters/3.png)");
                per3.setAttribute("style", "background-image:" + "url(images/characters/5selected.png)");
                per4.setAttribute("style", "background-image:" + "url(images/characters/7.png)");
                per5.setAttribute("style", "background-image:" + "url(images/characters/9.png)");
                per6.setAttribute("style", "background-image:" + "url(images/characters/11.png)");
                this.innerHTML = "Выбран";
                gal2.innerHTML = "Выбрать";
                gal1.innerHTML = "Выбрать";
                if (localStorage.getItem("pers4") == "true")
                gal4.innerHTML = "Выбрать";
                if (localStorage.getItem("pers5") == "true")
                gal5.innerHTML = "Выбрать";
                if (localStorage.getItem("pers6") == "true")
                gal6.innerHTML = "Выбрать";
                persona = 5;
                localStorage.setItem("pers", persona);
            }
                else if (parseInt(localStorage.getItem("mon")) >= parseInt(this.innerHTML)) {
                        let temp = parseInt(localStorage.getItem("mon")) - parseInt(this.innerHTML);
                        localStorage.setItem("mon", temp);
                        localStorage.setItem("pers3", "true");
                        document.getElementById("moneys4").innerHTML = localStorage.getItem("mon");
                        per1.setAttribute("style", "background-image:" + "url(images/characters/1.png)");
                        per2.setAttribute("style", "background-image:" + "url(images/characters/3.png)");
                        per3.setAttribute("style", "background-image:" + "url(images/characters/5selected.png)");
                        per4.setAttribute("style", "background-image:" + "url(images/characters/7.png)");
                        per5.setAttribute("style", "background-image:" + "url(images/characters/9.png)");
                        per6.setAttribute("style", "background-image:" + "url(images/characters/11.png)");
                        this.innerHTML = "Выбран";
                        gal2.innerHTML = "Выбрать";
                        gal1.innerHTML = "Выбрать";
                        if (localStorage.getItem("pers4") == "true")
                        gal4.innerHTML = "Выбрать";
                        if (localStorage.getItem("pers5") == "true")
                        gal5.innerHTML = "Выбрать";
                        if (localStorage.getItem("pers6") == "true")
                        gal6.innerHTML = "Выбрать";
                        persona = 5;
                        localStorage.setItem("pers", persona);
                    }
                }
            else if (this.value == "4") {
                if (localStorage.getItem("pers4") == "true") {
                per1.setAttribute("style", "background-image:" + "url(images/characters/1.png)");
                per2.setAttribute("style", "background-image:" + "url(images/characters/3.png)");
                per3.setAttribute("style", "background-image:" + "url(images/characters/5.png)");
                per4.setAttribute("style", "background-image:" + "url(images/characters/7selected.png)");
                per5.setAttribute("style", "background-image:" + "url(images/characters/9.png)");
                per6.setAttribute("style", "background-image:" + "url(images/characters/11.png)");
                this.innerHTML = "Выбран";
                gal2.innerHTML = "Выбрать";
                if (localStorage.getItem("pers3") == "true")
                gal3.innerHTML = "Выбрать";
                gal1.innerHTML = "Выбрать";
                if (localStorage.getItem("pers5") == "true")
                gal5.innerHTML = "Выбрать";
                if (localStorage.getItem("pers6") == "true")
                gal6.innerHTML = "Выбрать";
                persona = 7;
                localStorage.setItem("pers", persona);
            }
            else if (parseInt(localStorage.getItem("mon")) >= parseInt(this.innerHTML)){
                let temp = parseInt(localStorage.getItem("mon")) - parseInt(this.innerHTML);
                localStorage.setItem("mon", temp);
                localStorage.setItem("pers4", "true");
                document.getElementById("moneys4").innerHTML = localStorage.getItem("mon");
                per1.setAttribute("style", "background-image:" + "url(images/characters/1.png)");
                per2.setAttribute("style", "background-image:" + "url(images/characters/3.png)");
                per3.setAttribute("style", "background-image:" + "url(images/characters/5.png)");
                per4.setAttribute("style", "background-image:" + "url(images/characters/7selected.png)");
                per5.setAttribute("style", "background-image:" + "url(images/characters/9.png)");
                per6.setAttribute("style", "background-image:" + "url(images/characters/11.png)");
                this.innerHTML = "Выбран";
                gal2.innerHTML = "Выбрать";
                if (localStorage.getItem("pers3") == "true")
                gal3.innerHTML = "Выбрать";
                gal1.innerHTML = "Выбрать";
                if (localStorage.getItem("pers5") == "true")
                gal5.innerHTML = "Выбрать";
                if (localStorage.getItem("pers6") == "true")
                gal6.innerHTML = "Выбрать";
                persona = 7;
                localStorage.setItem("pers", persona);
            }
        }
            else if (this.value == "5") {
                if (localStorage.getItem("pers5") == "true"){
                per1.setAttribute("style", "background-image:" + "url(images/characters/1.png)");
                per2.setAttribute("style", "background-image:" + "url(images/characters/3.png)");
                per3.setAttribute("style", "background-image:" + "url(images/characters/5.png)");
                per4.setAttribute("style", "background-image:" + "url(images/characters/7.png)");
                per5.setAttribute("style", "background-image:" + "url(images/characters/9selected.png)");
                per6.setAttribute("style", "background-image:" + "url(images/characters/11.png)");
                this.innerHTML = "Выбран";
                gal2.innerHTML = "Выбрать";
                if (localStorage.getItem("pers3") == "true")
                gal3.innerHTML = "Выбрать";
                if (localStorage.getItem("pers4") == "true")
                gal4.innerHTML = "Выбрать";
                gal1.innerHTML = "Выбрать";
                if (localStorage.getItem("pers6") == "true")
                gal6.innerHTML = "Выбрать";
                persona = 9;
                localStorage.setItem("pers", persona);
            }
            else if (parseInt(localStorage.getItem("mon")) >= parseInt(this.innerHTML)) {
                let temp = parseInt(localStorage.getItem("mon")) - parseInt(this.innerHTML);
                localStorage.setItem("mon", temp);
                localStorage.setItem("pers5", "true");
                document.getElementById("moneys4").innerHTML = localStorage.getItem("mon");
                per1.setAttribute("style", "background-image:" + "url(images/characters/1.png)");
                per2.setAttribute("style", "background-image:" + "url(images/characters/3.png)");
                per3.setAttribute("style", "background-image:" + "url(images/characters/5.png)");
                per4.setAttribute("style", "background-image:" + "url(images/characters/7.png)");
                per5.setAttribute("style", "background-image:" + "url(images/characters/9selected.png)");
                per6.setAttribute("style", "background-image:" + "url(images/characters/11.png)");
                this.innerHTML = "Выбран";
                gal2.innerHTML = "Выбрать";
                if (localStorage.getItem("pers3") == "true")
                gal3.innerHTML = "Выбрать";
                if (localStorage.getItem("pers4") == "true")
                gal4.innerHTML = "Выбрать";
                gal1.innerHTML = "Выбрать";
                if (localStorage.getItem("pers6") == "true")
                gal6.innerHTML = "Выбрать";
                persona = 9;
                localStorage.setItem("pers", persona);
            }
            }
            else if (this.value == "6") {
                if (localStorage.getItem("pers6") == "true"){
                per1.setAttribute("style", "background-image:" + "url(images/characters/1.png)");
                per2.setAttribute("style", "background-image:" + "url(images/characters/3.png)");
                per3.setAttribute("style", "background-image:" + "url(images/characters/5.png)");
                per4.setAttribute("style", "background-image:" + "url(images/characters/7.png)");
                per5.setAttribute("style", "background-image:" + "url(images/characters/9.png)");
                per6.setAttribute("style", "background-image:" + "url(images/characters/11selected.png)");
                this.innerHTML = "Выбран";
                gal2.innerHTML = "Выбрать";
                if (localStorage.getItem("pers3") == "true")
                gal3.innerHTML = "Выбрать";
                if (localStorage.getItem("pers4") == "true")
                gal4.innerHTML = "Выбрать";
                if (localStorage.getItem("pers5") == "true")
                gal5.innerHTML = "Выбрать";
                gal1.innerHTML = "Выбрать";
                persona = 11;
                localStorage.setItem("pers", persona);
            }
            else if (parseInt(localStorage.getItem("mon")) >= parseInt(this.innerHTML)) {
                let temp = parseInt(localStorage.getItem("mon")) - parseInt(this.innerHTML);
                localStorage.setItem("mon", temp);
                localStorage.setItem("pers6", "true");
                document.getElementById("moneys4").innerHTML = localStorage.getItem("mon");
                per1.setAttribute("style", "background-image:" + "url(images/characters/1.png)");
                per2.setAttribute("style", "background-image:" + "url(images/characters/3.png)");
                per3.setAttribute("style", "background-image:" + "url(images/characters/5.png)");
                per4.setAttribute("style", "background-image:" + "url(images/characters/7.png)");
                per5.setAttribute("style", "background-image:" + "url(images/characters/9.png)");
                per6.setAttribute("style", "background-image:" + "url(images/characters/11selected.png)");
                this.innerHTML = "Выбран";
                gal2.innerHTML = "Выбрать";
                if (localStorage.getItem("pers3") == "true")
                gal3.innerHTML = "Выбрать";
                if (localStorage.getItem("pers4") == "true")
                gal4.innerHTML = "Выбрать";
                if (localStorage.getItem("pers5") == "true")
                gal5.innerHTML = "Выбрать";
                gal1.innerHTML = "Выбрать";
                persona = 11;
                localStorage.setItem("pers", persona);
            }
        }
                pickAcs = 0;
                localStorage.setItem("acs", pickAcs);
                gul0.innerHTML = "Выбран";
                if (localStorage.getItem("acs1") == "true")
                gul1.innerHTML = "Выбрать";
                acs0.setAttribute("style", "background-image:" + "url(images/characters/acs0selected.png)");
                acs1.setAttribute("style", "background-image:" + "url(images/characters/acs1.png)");
    }
    }
//    END SKINS
    function showMenu() {
        let bod = document.body;
        bod.style.backgroundColor = "rgb(122, 164, 225)";
        localStorage.setItem("acs0", "true");
        if (localStorage.getItem("acs1") == null){
            localStorage.setItem("acs1", "false");
        }
        localStorage.setItem("pers1", "true");
        localStorage.setItem("pers2", "true");
        if (localStorage.getItem("pers3") == null){
            localStorage.setItem("pers3", "false");
        }
        if (localStorage.getItem("pers4") == null){
            localStorage.setItem("pers4", "false");
        }
        if (localStorage.getItem("pers5") == null){
            localStorage.setItem("pers5", "false");
        }
        if (localStorage.getItem("pers6") == null){
            localStorage.setItem("pers6", "false");
        }
        isGameOver = false;
        flag = true;
        flagflag = true;
        restarts.style.display = "none";
        main.style.display = "none";
        clouds = [];
        platforms = [];
        moneys = [];
        candys = [];
        q = 60;
        qq = 1;
        score = 0;
        name.style.display = "block";
        menu.style.display = "block";
        game.style.display = "none";
        shops.style.display = "block";
        str.style.display = "block";
        if (localStorage.getItem("mon") == null){
            monValue.innerHTML = 0;
            document.getElementById("moneys4").innerHTML = 0;
        }
        else {
            monValue.innerHTML = localStorage.getItem("mon");
            document.getElementById("moneys4").innerHTML = localStorage.getItem("mon");
        }
        if (localStorage.getItem("rait") == null || localStorage.getItem("rait") == "0"){
            localStorage.setItem("rait", 0);
        }
        else {
            if (parseInt(localStorage.getItem("rait")) >= 1000000) raitValue.style.color = "red";
            raitValue.innerHTML = "Рекорд" +"<br>" + localStorage.getItem("rait");
        }
        if (localStorage.getItem("pers") == null)
            localStorage.setItem("pers", persona);
        else {
            persona = parseInt(localStorage.getItem("pers"));
        }
        if (localStorage.getItem("acs") == null){
            localStorage.setItem("acs", pickAcs);
            pickAcs = parseInt(localStorage.getItem("acs"));
        }
        else {
            pickAcs = parseInt(localStorage.getItem("acs"));
    }
        pickPer = parseInt(persona);
        let choice;
        choice = "url(images/characters/" + persona + ".png)";
        hum.setAttribute("style", "background-image:" + choice);
            checkPers();
            checkAcs();
    }
    window.addEventListener('keydown', function (e) {
            e.preventDefault();
            keyState[e.keyCode || e.which] = true;
        }, true);

        window.addEventListener('keyup', function (e) {
            e.preventDefault();
            keyState[e.keyCode || e.which] = false;
        }, true);
    showMenu();
});